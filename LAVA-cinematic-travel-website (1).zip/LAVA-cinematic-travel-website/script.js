(() => {
  "use strict";

  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------- Mobile navigation ----------
  const nav = document.querySelector(".nav");
  const menuToggle = document.querySelector(".menu-toggle");

  menuToggle?.addEventListener("click", () => {
    nav.classList.toggle("mobile-open");
    menuToggle.textContent = nav.classList.contains("mobile-open") ? "×" : "☰";
  });

  document.querySelectorAll(".desktop-nav a, .nav-cta").forEach(link => {
    link.addEventListener("click", () => {
      nav.classList.remove("mobile-open");
      menuToggle.textContent = "☰";
    });
  });

  // ---------- Three.js cinematic hero ----------
  const canvas = document.getElementById("hero-canvas");

  if (canvas && window.THREE) {
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x071510, 0.012);

    const camera = new THREE.PerspectiveCamera(
      52,
      window.innerWidth / window.innerHeight,
      0.1,
      300
    );
    camera.position.set(0, 7, 24);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;

    const ambient = new THREE.HemisphereLight(0xcfe8d1, 0x071510, 1.5);
    scene.add(ambient);

    const sun = new THREE.DirectionalLight(0xffd6a3, 2.6);
    sun.position.set(-12, 18, 12);
    scene.add(sun);

    const moon = new THREE.PointLight(0xb8d7a2, 18, 100);
    moon.position.set(10, 9, -8);
    scene.add(moon);

    // Water plane
    const waterGeo = new THREE.PlaneGeometry(180, 180, 60, 60);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x164031,
      roughness: .25,
      metalness: .15,
      transparent: true,
      opacity: .93
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.rotation.x = -Math.PI / 2;
    water.position.y = -1.6;
    scene.add(water);

    // Sunset disc
    const sunDisc = new THREE.Mesh(
      new THREE.SphereGeometry(4.2, 40, 40),
      new THREE.MeshBasicMaterial({ color: 0xffc884 })
    );
    sunDisc.position.set(-19, 12, -52);
    scene.add(sunDisc);

    // Distant mountain silhouettes
    function addMountain(x, z, scale, color) {
      const geo = new THREE.ConeGeometry(7 * scale, 8 * scale, 4);
      const mat = new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: 1 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, 2 * scale, z);
      mesh.rotation.y = Math.PI / 4;
      scene.add(mesh);
      return mesh;
    }

    [
      [-22, -42, 2.3, 0x0b241b],
      [-8, -49, 1.9, 0x102e22],
      [8, -45, 2.8, 0x0b241b],
      [24, -50, 2.0, 0x102c21]
    ].forEach(m => addMountain(...m));

    // Simple luxury resort made from geometry
    const resort = new THREE.Group();

    const hotelMat = new THREE.MeshStandardMaterial({
      color: 0xe8e4d6,
      roughness: .52,
      metalness: .05
    });
    const roofMat = new THREE.MeshStandardMaterial({
      color: 0x12291f,
      roughness: .7
    });
    const windowMat = new THREE.MeshStandardMaterial({
      color: 0xb7e1d0,
      emissive: 0x23483a,
      emissiveIntensity: 1.7,
      roughness: .16,
      metalness: .2
    });

    const mainBuilding = new THREE.Mesh(
      new THREE.BoxGeometry(13, 5.5, 5),
      hotelMat
    );
    mainBuilding.position.set(2, 1.2, -19);
    resort.add(mainBuilding);

    const roof = new THREE.Mesh(
      new THREE.BoxGeometry(14, .45, 6),
      roofMat
    );
    roof.position.set(2, 4.15, -19);
    resort.add(roof);

    // Glass facade strips
    for (let x = -3.2; x <= 7.2; x += 2) {
      const window = new THREE.Mesh(
        new THREE.BoxGeometry(.9, 2.1, .06),
        windowMat
      );
      window.position.set(x, 1.7, -16.48);
      resort.add(window);
    }

    // Villas
    for (let i = 0; i < 3; i++) {
      const villa = new THREE.Mesh(
        new THREE.BoxGeometry(4.5, 2.8, 4),
        hotelMat
      );
      villa.position.set(-11 + i * 5.5, .4, -14 - i * .4);
      resort.add(villa);

      const villaRoof = new THREE.Mesh(
        new THREE.BoxGeometry(5, .35, 4.5),
        roofMat
      );
      villaRoof.position.copy(villa.position);
      villaRoof.position.y += 1.6;
      resort.add(villaRoof);
    }

    // Infinity pool
    const pool = new THREE.Mesh(
      new THREE.BoxGeometry(18, .55, 6),
      new THREE.MeshStandardMaterial({ color: 0x2e8f86, metalness: .12, roughness: .1 })
    );
    pool.position.set(2, -1.05, -14.7);
    resort.add(pool);

    scene.add(resort);

    // Palm trees
    function palm(x, z, scale = 1) {
      const group = new THREE.Group();

      const trunk = new THREE.Mesh(
        new THREE.CylinderGeometry(.14 * scale, .22 * scale, 4.6 * scale, 8),
        new THREE.MeshStandardMaterial({ color: 0x5c4630, roughness: 1 })
      );
      trunk.position.y = 1.1 * scale;
      group.add(trunk);

      const leafMat = new THREE.MeshStandardMaterial({
        color: 0x356348,
        side: THREE.DoubleSide,
        roughness: 1
      });

      for (let i = 0; i < 7; i++) {
        const leaf = new THREE.Mesh(
          new THREE.ConeGeometry(.55 * scale, 3.5 * scale, 4),
          leafMat
        );
        leaf.position.y = 3.55 * scale;
        leaf.rotation.z = Math.PI / 2.45;
        leaf.rotation.y = (i / 7) * Math.PI * 2;
        leaf.position.x += Math.cos(leaf.rotation.y) * 1.2 * scale;
        leaf.position.z += Math.sin(leaf.rotation.y) * 1.2 * scale;
        group.add(leaf);
      }

      group.position.set(x, -1.45, z);
      scene.add(group);
      return group;
    }

    const palms = [
      palm(-18, -18, 1.15),
      palm(-13, -10, .9),
      palm(13, -12, 1.05),
      palm(19, -19, 1.2),
      palm(7, -8, .72)
    ];

    // Atmospheric particles
    const particleCount = window.innerWidth < 700 ? 900 : 1500;
    const particlesGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - .5) * 95;
      positions[i * 3 + 1] = Math.random() * 45 - 5;
      positions[i * 3 + 2] = (Math.random() - .5) * 90 - 10;
    }

    particlesGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));

    const particles = new THREE.Points(
      particlesGeo,
      new THREE.PointsMaterial({
        color: 0xb8d7a2,
        size: .085,
        transparent: true,
        opacity: .42,
        depthWrite: false
      })
    );
    scene.add(particles);

    const mouse = { x: 0, y: 0 };
    window.addEventListener("pointermove", e => {
      mouse.x = (e.clientX / window.innerWidth - .5) * 2;
      mouse.y = (e.clientY / window.innerHeight - .5) * 2;
    }, { passive: true });

    let targetZ = 24;
    let cameraZ = 24;
    let scrollRatio = 0;

    window.addEventListener("scroll", () => {
      scrollRatio = Math.min(window.scrollY / Math.max(window.innerHeight, 1), 1.2);
      targetZ = 24 - scrollRatio * 9;
    }, { passive: true });

    const clock = new THREE.Clock();

    function animate() {
      requestAnimationFrame(animate);
      const t = clock.getElapsedTime();

      const pos = water.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const z = pos.getY(i);
        pos.setZ(i, Math.sin(x * .12 + t * .8) * .16 + Math.cos(z * .15 + t * .6) * .1);
      }
      pos.needsUpdate = true;

      palms.forEach((p, i) => {
        p.rotation.z = Math.sin(t * .55 + i) * .018;
      });

      particles.rotation.y = t * .008;

      cameraZ += (targetZ - cameraZ) * .035;
      camera.position.z = cameraZ;
      camera.position.x += ((mouse.x * 1.3) - camera.position.x) * .02;
      camera.position.y += ((7 - mouse.y * .6) - camera.position.y) * .02;
      camera.lookAt(0, 0.8, -18);

      renderer.render(scene, camera);
    }

    animate();

    function resize() {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.6));
      renderer.setSize(window.innerWidth, window.innerHeight);
    }
    window.addEventListener("resize", resize);
  }

  // ---------- GSAP reveals ----------
  if (window.gsap && window.ScrollTrigger && !reducedMotion) {
    gsap.registerPlugin(ScrollTrigger);

    gsap.from(".hero .reveal", {
      y: 50,
      opacity: 0,
      duration: 1.15,
      stagger: .12,
      ease: "power4.out",
      delay: .15
    });

    gsap.to(".hero-copy", {
      yPercent: -25,
      opacity: .2,
      scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true
      }
    });

    gsap.utils.toArray(".section-heading, .featured-copy, .value-item, .hotel-card, .support-card").forEach(el => {
      gsap.from(el, {
        y: 50,
        opacity: 0,
        duration: .9,
        ease: "power3.out",
        scrollTrigger: {
          trigger: el,
          start: "top 82%"
        }
      });
    });

    gsap.utils.toArray(".experience-card").forEach((card, i) => {
      gsap.from(card, {
        x: 80,
        opacity: 0,
        duration: .9,
        delay: i * .05,
        ease: "power3.out",
        scrollTrigger: {
          trigger: ".experience-rail",
          start: "top 82%"
        }
      });
    });

    gsap.to(".floating-orb.orb-1", {
      y: -100,
      x: 40,
      rotate: 90,
      scrollTrigger: {
        trigger: ".final-cta",
        start: "top bottom",
        end: "bottom top",
        scrub: true
      }
    });

    gsap.to(".floating-orb.orb-2", {
      y: 80,
      x: -40,
      rotate: -90,
      scrollTrigger: {
        trigger: ".final-cta",
        start: "top bottom",
        end: "bottom top",
        scrub: true
      }
    });
  }

  // ---------- Destination cinematic stack ----------
  const destinationCards = [...document.querySelectorAll(".destination-card")];
  const journeySection = document.querySelector(".journey");

  if (destinationCards.length && !reducedMotion && window.gsap && window.ScrollTrigger) {
    gsap.registerPlugin(ScrollTrigger);

    ScrollTrigger.create({
      trigger: journeySection,
      start: "top top",
      end: "+=2800",
      pin: true,
      scrub: true,
      onUpdate: self => {
        const index = Math.min(
          destinationCards.length - 1,
          Math.floor(self.progress * destinationCards.length)
        );

        destinationCards.forEach((card, i) => {
          card.classList.toggle("active", i === index);
        });
      }
    });
  }

  // ---------- Hotel filters ----------
  const filterButtons = document.querySelectorAll(".filter");
  const hotelCards = document.querySelectorAll(".hotel-card");

  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      filterButtons.forEach(b => b.classList.remove("active"));
      button.classList.add("active");

      const filter = button.dataset.filter;

      hotelCards.forEach(card => {
        const matches = filter === "all" || card.dataset.type.includes(filter);
        card.classList.toggle("hidden", !matches);
      });
    });
  });

  // ---------- Magnetic buttons ----------
  if (!reducedMotion) {
    document.querySelectorAll(".magnetic").forEach(el => {
      el.addEventListener("pointermove", e => {
        const r = el.getBoundingClientRect();
        const x = e.clientX - r.left - r.width / 2;
        const y = e.clientY - r.top - r.height / 2;
        el.style.transform = `translate(${x * .12}px, ${y * .12}px)`;
      });
      el.addEventListener("pointerleave", () => {
        el.style.transform = "";
      });
    });
  }

  // ---------- Fake support interactions ----------
  const toast = document.getElementById("toast");
  document.querySelectorAll(".support-card").forEach(card => {
    card.addEventListener("click", e => {
      if (card.getAttribute("href") === "#contact") {
        toast.textContent = "Opening Lava contact options…";
        toast.classList.add("show");
        setTimeout(() => toast.classList.remove("show"), 2200);
      }
    });
  });
})();
