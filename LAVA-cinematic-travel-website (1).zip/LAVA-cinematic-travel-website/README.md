# LAVA — Cinematic 3D Travel Website

A static, GitHub Pages-friendly luxury travel website built with:

- HTML
- CSS
- Vanilla JavaScript
- Three.js (CDN)
- GSAP + ScrollTrigger (CDN)

## Run locally

Because the project uses CDN libraries and no build step, you can open `index.html` directly in a browser. For best results, use VS Code + Live Server.

## Publish on GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, and `script.js`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/root`.
6. Save, then open the GitHub Pages URL.

## Customize

Edit the text in `index.html`.

Edit the visual system in `styles.css`:
- `--green`
- `--lime`
- `--ivory`
- `--gold`

Replace the Unsplash URLs in `styles.css` with your client's approved hotel/destination photos.

## Notes

- The 3D hero is generated procedurally with Three.js, so no paid 3D assets are required.
- External image URLs are used for the demo. Replace them with client-approved assets before delivering a production website.
- For a real booking/support backend, connect the CTA/contact interactions to the client's actual CRM, email service, booking engine, or form provider.
